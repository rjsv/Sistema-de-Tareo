<?php

return array (
  'title' => 'Laravel Installer',
  'next' => 'Passo successivo',
  'finish' => 'Installa',
  'welcome' => 
  array (
    'title' => 'Benvenuto al programma di installazione',
    'message' => 'Benvenuto alla configurazione guidata.',
  ),
  'requirements' => 
  array (
    'title' => 'Requisiti',
  ),
  'permissions' => 
  array (
    'title' => 'Permessi',
  ),
  'environment' => 
  array (
    'title' => 'Configurazione ambiente',
    'save' => 'Salva .env',
    'success' => 'La configurazione del file .env &egrave; stata salvata correttamente.',
    'errors' => 'Impossibile salvare il file .env, per favore crealo manualmente.',
  ),
  'final' => 
  array (
    'title' => 'Finito',
    'finished' => 'L\'applicazione è stata configurata correttamente.',
    'exit' => 'Clicca qui per uscire',
  ),
);
