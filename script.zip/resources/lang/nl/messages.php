<?php

return array (
  'title' => 'Laravel Installer',
  'next' => 'Volgende stap',
  'welcome' => 
  array (
    'title' => 'Welkom bij het installatie proces...',
    'message' => 'Welkom bij de installatiewizard',
  ),
  'requirements' => 
  array (
    'title' => 'Vereisten',
  ),
  'permissions' => 
  array (
    'title' => 'Permissies',
  ),
  'environment' => 
  array (
    'title' => 'Environment Settings',
    'save' => '.env Opslaan',
    'success' => 'Uw .env bestand is opgeslagen.',
    'errors' => 'Het is niet mogelijk om een .env bestand aan te maken, maak a.u.b het bestand zelf aan.',
  ),
  'final' => 
  array (
    'title' => 'Voltooid',
    'finished' => 'Applicatie is succesvol geïnstalleerd.',
    'exit' => 'Klik hier om af te sluiten.',
  ),
);
