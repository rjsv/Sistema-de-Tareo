<?php

return array (
  'title' => 'Procesul de instalare Laravel',
  'next' => 'Pasul următor',
  'welcome' => 
  array (
    'title' => 'Bun venit în procesul de instalare...',
    'message' => 'Bun venit în configurarea asistată.',
  ),
  'requirements' => 
  array (
    'title' => 'Cerințe',
  ),
  'permissions' => 
  array (
    'title' => 'Permisiuni',
  ),
  'environment' => 
  array (
    'title' => 'Settări ale mediului',
    'save' => 'Salvează fișier .env',
    'success' => 'Setările tale au fost salvate în fișierul .env.',
    'errors' => 'Nu am putut salva fișierul .env, Te rugăm să-l creezi manual.',
  ),
  'final' => 
  array (
    'title' => 'Am terminat',
    'finished' => 'Aplicația a fost instalată cu succes.',
    'exit' => 'Click aici pentru a ieși',
  ),
);
