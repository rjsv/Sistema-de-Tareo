<?php

return array (
  'title' => 'Laraveli installer',
  'next' => 'Järgmine samm',
  'welcome' => 
  array (
    'title' => 'Tere tulemast Laraveli installerisse',
    'message' => 'Tere tulemast installatsiooniviisardisse.',
  ),
  'requirements' => 
  array (
    'title' => 'Nõuded',
  ),
  'permissions' => 
  array (
    'title' => 'Õigused',
  ),
  'environment' => 
  array (
    'title' => 'Keskkonna seaded',
    'save' => 'Salvesta .env',
    'success' => 'Sinu .env faili seaded on salvestatud.',
    'errors' => 'Ei saanud .env faili salvesta, palun loo see manuaalselt.',
  ),
  'final' => 
  array (
    'title' => 'Lõpetatud',
    'finished' => 'Laravel on edukalt installitud',
    'exit' => 'Väljumiseks vajuta siia',
  ),
);
