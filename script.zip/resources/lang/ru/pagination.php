<?php

return array (
  'previous' => '&laquo; Назад',
  'next' => 'Вперёд &raquo;',
  'Show' => 'Показать',
);
