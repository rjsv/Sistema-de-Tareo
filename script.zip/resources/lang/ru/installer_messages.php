<?php

return array (
  'checkPermissionAgain' => 'Проверить разрешение снова',
  'environment' => 
  array (
    'errors' => 'Не удалось сохранить файл .env, создайте его вручную.',
    'save' => 'Сохранить .env',
    'success' => 'Настройки файла .env сохранены.',
    'title' => 'Настройки среды',
  ),
  'final' => 
  array (
    'exit' => 'Нажмите здесь, чтобы выйти',
    'finished' => 'Приложение успешно установлено.',
    'title' => 'Законченный.',
  ),
  'finish' => 'Устанавливать',
  'install' => 'Устанавливать',
  'next' => 'Следующий шаг',
  'permissions' => 
  array (
    'title' => 'Права доступа',
  ),
  'requirements' => 
  array (
    'title' => 'Требования',
  ),
  'title' => 'Установщик Laravel',
  'welcome' => 
  array (
    'message' => 'Добро пожаловать в мастер настройки.',
    'title' => 'Добро пожаловать в установщик',
  ),
);
