<?php

return array (
  'title' => 'Laravel Instalator',
  'next' => 'Następny krok',
  'welcome' => 
  array (
    'title' => 'Instalacja Laravel',
    'message' => 'Witaj w kreatorze instalacji.',
  ),
  'requirements' => 
  array (
    'title' => 'Wymagania systemowe ',
  ),
  'permissions' => 
  array (
    'title' => 'Uprawnienia',
  ),
  'environment' => 
  array (
    'title' => 'Ustawnienia środowiska',
    'save' => 'Zapisz .env',
    'success' => 'Plik .env został poprawnie zainstalowany.',
    'errors' => 'Nie można zapisać pliku .env, Proszę utworzyć go ręcznie.',
  ),
  'final' => 
  array (
    'title' => 'Instalacja zakończona',
    'finished' => 'Aplikacja została poprawnie zainstalowana.',
    'exit' => 'Kliknij aby zakończyć',
  ),
);
